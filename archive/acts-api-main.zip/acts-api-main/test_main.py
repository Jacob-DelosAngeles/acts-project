"""Tests for ACTS API."""

import main


main.app.testing = True


class TestMain:
    client = main.app.test_client()

    def test__osm_ways__no_query(self):
        response = self.client.get("/osm/ways")

        assert response.status_code == 200
        assert len(response.json) == 0
        assert isinstance(response.json, dict)

    def test__osm_ways__datasets_missing(self):
        response = self.client.get("/osm/ways?q=unknown")

        assert response.status_code == 200
        assert len(response.json) == 0
        assert isinstance(response.json, dict)

    def test__osm_ways__quezon_city(self):
        response = self.client.get("/osm/ways?q=quezon+city")

        assert response.status_code == 200
        assert len(response.json) == 24760
        assert isinstance(response.json, dict)

        assert response.json["1052579105"] == [
            [14.6123437, 121.0610677],
            [14.6124351, 121.0610197],
            [14.6143017, 121.0601599],
            [14.616023, 121.0593611],
        ]

        assert response.json["1053790779"] == [
            [14.695562, 121.0597742],
            [14.6955607, 121.059871],
        ]
