from __future__ import annotations

import numpy as np
import pandas as pd

import acts.core as acts


def main():
    """Load and return the sample coded dataset (classification)."""

    # Load the initial dataframe and make sure all the columns are uppercase
    # This is our expected format so let's force it to the `df` variable
    df = pd.read_excel("samples/before.xlsx")
    df.columns = map(str.lower, df.columns)

    travel_significant_vars, df = acts.model.TravelDecisionMLogit(df)
    activity_siginificant_vars, dfs = acts.model.ActivityChoiceMLogit(df)
    dest_siginificant_vars, dfs = acts.model.DestinationChoiceMLogit(dfs)

    # print("=" * 40)
    print(activity_siginificant_vars)


if __name__ == "__main__":
    main()
